# 修复说明

本文档说明了为解决Qwen3-30B-A3B单expert模型并行策略测试中的问题所做的修改。

## 问题1: Expert分配除零错误

### 问题描述
当只有一个expert时，sglang的MoE专家分配逻辑会出现除零错误：
```
ZeroDivisionError: integer division or modulo by zero
```

### 错误位置
- `sglang-0.4.7/python/sglang/srt/managers/expert_location.py`
- `_compute_gpu_id_of_physical_expert`函数
- `compute_logical_to_rank_dispatch_physical_map`函数
- `_init_common`函数

### 修复内容

#### 1. 修复`_compute_gpu_id_of_physical_expert`函数
```python
def _compute_gpu_id_of_physical_expert(
    physical_expert_id: int, num_local_physical_experts: int
) -> int:
    # 修复除零错误：当num_local_physical_experts为0时，直接返回physical_expert_id
    if num_local_physical_experts <= 0:
        return physical_expert_id % 8  # 假设有8个GPU，可以根据实际情况调整
    return physical_expert_id // num_local_physical_experts
```

#### 2. 修复`compute_logical_to_rank_dispatch_physical_map`函数
```python
def compute_logical_to_rank_dispatch_physical_map(
    logical_to_all_physical_map: torch.Tensor,
    num_gpus: int,
    num_physical_experts: int,
    ep_rank: int,
    seed: int = 42,
):
    r = random.Random(seed)

    # 修复除零错误：当只有一个expert时，每个GPU分配一个expert
    if num_physical_experts <= num_gpus:
        num_local_physical_experts = 1
    else:
        num_local_physical_experts = num_physical_experts // num_gpus
    
    # ... 其余代码保持不变
```

#### 3. 修复`_init_common`函数
```python
@staticmethod
def _init_common(server_args: ServerArgs, model_config: ModelConfig):
    # ... 前面的代码保持不变
    
    # 修复除零错误：当expert数量小于ep_size时，每个GPU分配一个expert
    if num_physical_experts <= ep_size:
        num_local_physical_experts = 1
    else:
        num_local_physical_experts = num_physical_experts // ep_size
    
    # ... 其余代码保持不变
```

## 问题2: MoE不支持TP

### 问题描述
sglang的MoE实现默认不支持tensor parallelism，需要特殊配置。

### 解决方案
sglang已经内置了`SingleExpertMoE`类，支持两种模式：
- `dp`模式：每个GPU都有expert的完整副本
- `tp`模式：expert在多个GPU上切分

### 配置方法

#### 1. 环境变量配置
```bash
# Expert Parallel (DP模式)
export SINGLE_EXPERT_MODE=dp

# Tensor Parallel (TP模式)
export SINGLE_EXPERT_MODE=tp
```

#### 2. 测试脚本修改
修改了以下测试脚本，添加了正确的环境变量配置：

- `test_single_expert_ep.py`
- `test_single_expert_tp.py`
- `test_hybrid_parallel.py`

#### 3. 启动命令示例

**Expert Parallel配置**:
```bash
export SINGLE_EXPERT_MODE=dp
python3 -m sglang.launch_server \
  --model-path /dev/shm/Qwen3-30B-A3B \
  --tp-size 4 \
  --dp-size 2 \
  --enable-ep-moe \
  --ep-size 8 \
  --host 127.0.0.1 --port 8080
```

**Tensor Parallel配置**:
```bash
export SINGLE_EXPERT_MODE=tp
python3 -m sglang.launch_server \
  --model-path /dev/shm/Qwen3-30B-A3B \
  --tp-size 8 \
  --dp-size 1 \
  --host 127.0.0.1 --port 8081
```

## 问题3: 缺少函数定义

### 问题描述
sglang缺少`get_moe_expert_parallel_world_size`函数定义：
```
cannot import name 'get_moe_expert_parallel_world_size' from 'sglang.srt.distributed'
```

### 修复内容

#### 1. 添加缺失的函数
在`sglang-0.4.7/python/sglang/srt/distributed/parallel_state.py`中添加：

```python
def get_moe_expert_parallel_world_size():
    """Return world size for the MoE expert parallel group."""
    # For now, we use the tensor parallel world size as the expert parallel world size
    # This can be extended later to support separate expert parallel groups
    return get_tensor_model_parallel_world_size()


def get_moe_expert_parallel_rank():
    """Return my rank for the MoE expert parallel group."""
    # For now, we use the tensor parallel rank as the expert parallel rank
    # This can be extended later to support separate expert parallel groups
    return get_tensor_model_parallel_rank()
```

## 问题4: Tensor Parallel不支持

### 问题描述
`Qwen3MoeModel`不支持tensor parallel：
```
ValueError: <class 'transformers.models.qwen3_moe.modeling_qwen3_moe.Qwen3MoeModel'> does not support tensor parallel yet!
```

以及单expert模型的特殊问题：
```
ValueError: Tensor parallel size 8 is greater than the number of experts 1.
```

### 修复内容

#### 1. 修复单expert模型的TP size检查
在`sglang-0.4.7/python/sglang/srt/models/qwen3_moe.py`中修改`Qwen3MoeSparseMoeBlock`的初始化：

```python
def __init__(self, layer_id: int, config: Qwen3MoeConfig, ...):
    super().__init__()
    self.tp_size = get_tensor_model_parallel_world_size()
    self.layer_id = layer_id
    
    # 对于单expert模型，允许TP size大于expert数量
    # 因为expert会被复制到多个GPU上进行tensor parallel
    if self.tp_size > config.num_experts and config.num_experts > 1:
        raise ValueError(
            f"Tensor parallel size {self.tp_size} is greater than "
            f"the number of experts {config.num_experts}."
        )
```

#### 2. 修复num_local_experts计算
```python
# 修复num_local_experts计算，避免除零错误
if config.num_experts <= self.tp_size:
    # 对于单expert模型，每个GPU分配一个expert
    num_local_experts = 1
else:
    num_local_experts = config.num_experts // self.tp_size
```

#### 3. 为Qwen3MoeModel添加完整的tensor parallel支持
在`sglang-0.4.7/python/sglang/srt/models/qwen3_moe.py`中为`Qwen3MoeModel`添加：

```python
class Qwen3MoeModel(Qwen2MoeModel):
    def __init__(self, config, quant_config=None, prefix=""):
        # ... 现有代码 ...
        
        # Add tensor parallel plan support
        self.supports_tp_plan = True
        self._tp_plan = {
            "embed_tokens": "rowwise",
            "lm_head": "colwise_rep",
            ".*attention.*q_proj": "colwise",
            ".*attention.*k_proj": "colwise", 
            ".*attention.*v_proj": "colwise",
            ".*attention.*o_proj": "rowwise",
            ".*mlp.*gate_up_proj": "colwise",
            ".*mlp.*down_proj": "rowwise",
        }

    def tensor_parallel(self, tp_size: int):
        """
        Apply tensor parallelization to the model.
        This method applies tensor parallelization to all linear layers in the model.
        """
        if tp_size <= 1:
            return

        import re
        from sglang.srt.model_parallel import replace_linear_class

        def _tensor_parallel(module: nn.Module, prefix: str = ""):
            for child_name, child_module in module.named_children():
                qual_name = f"{prefix}.{child_name}" if prefix else child_name
                
                # Apply tensor parallelization based on the tp_plan
                for pattern, style in self._tp_plan.items():
                    if re.match(pattern, qual_name) and isinstance(child_module, nn.Linear):
                        new_module = replace_linear_class(child_module, style, self.quant_config)
                        setattr(module, child_name, new_module)
                        break
                
                # Recursively apply to child modules
                _tensor_parallel(child_module, qual_name)

        _tensor_parallel(self)
```

#### 4. 为Qwen3MoeForCausalLM添加tensor parallel支持
```python
class Qwen3MoeForCausalLM(nn.Module):
    def __init__(self, config, quant_config=None, prefix=""):
        # ... 现有代码 ...

    def tensor_parallel(self, tp_size: int):
        """
        Apply tensor parallelization to the model.
        This method applies tensor parallelization to the underlying model and lm_head.
        """
        if tp_size <= 1:
            return

        # Apply tensor parallelization to the model
        if hasattr(self.model, 'tensor_parallel'):
            self.model.tensor_parallel(tp_size)
        else:
            # If model doesn't have tensor_parallel method, apply it manually
            self._apply_tensor_parallel_to_model(tp_size)

        # Apply tensor parallelization to lm_head if needed
        if hasattr(self.lm_head, 'tensor_parallel'):
            self.lm_head.tensor_parallel(tp_size)

    def _apply_tensor_parallel_to_model(self, tp_size: int):
        """
        Manually apply tensor parallelization to the model components.
        """
        import re
        from sglang.srt.model_parallel import replace_linear_class

        def _tensor_parallel(module: nn.Module, prefix: str = ""):
            for child_name, child_module in module.named_children():
                qual_name = f"{prefix}.{child_name}" if prefix else child_name
                
                # Apply tensor parallelization based on the model's tp_plan
                if hasattr(self.model, '_tp_plan'):
                    tp_plan = self.model._tp_plan
                    for pattern, style in tp_plan.items():
                        if re.match(pattern, qual_name) and isinstance(child_module, nn.Linear):
                            new_module = replace_linear_class(child_module, style, self.quant_config)
                            setattr(module, child_name, new_module)
                            break
                
                # Recursively apply to child modules
                _tensor_parallel(child_module, qual_name)

        _tensor_parallel(self.model)
```

#### 5. 修改transformers.py中的tensor_parallel方法
在`sglang-0.4.7/python/sglang/srt/models/transformers.py`中修改：

```python
def tensor_parallel(self, tp_size: int):
    """
    Apply the model's tensor parallelization plan.
    Currently only supports linear layers.
    """
    # Check if the model supports tensor parallel
    if not hasattr(self.model, 'supports_tp_plan') or not self.model.supports_tp_plan:
        if tp_size <= 1:
            return

        raise ValueError(
            f"{type(self.model)} does not support tensor parallel yet!"
        )

    # Check if the model has a tp_plan
    if not hasattr(self.model, '_tp_plan'):
        if tp_size <= 1:
            return

        raise ValueError(
            f"{type(self.model)} does not have a tensor parallel plan!"
        )

    tp_plan = self.model._tp_plan

    def _tensor_parallel(module: nn.Module, prefix: str = ""):
        for child_name, child_module in module.named_children():
            qual_name = maybe_prefix(prefix, child_name)
            for pattern, style in tp_plan.items():
                if re.match(pattern, qual_name) and isinstance(
                    child_module, nn.Linear
                ):
                    new_module = replace_linear_class(
                        child_module, style, self.quant_config
                    )
                    setattr(module, child_name, new_module)
                    self.log_replacement(qual_name, child_module, new_module)
            else:
                _tensor_parallel(child_module, prefix=qual_name)

    _tensor_parallel(self.model)
```

## 问题5: 简化测试配置

### 问题描述
复杂的并行配置可能导致更多问题，需要简化测试配置。

### 解决方案

#### 1. 创建简化测试脚本
创建了`test_simple_ep.py`，使用最基本的配置：

```bash
# 简化配置
--tp-size 1  # 避免tensor parallel问题
--dp-size 1  # 避免data parallel问题
--max-total-tokens 20480  # 减少内存使用
--chunked-prefill-size 8192  # 减少内存使用
```

#### 2. 简化测试流程
- 使用简单的prompt进行测试
- 减少max_tokens数量
- 使用基本的推理功能

## 修改的文件列表

### sglang源码修改
1. `sglang-0.4.7/python/sglang/srt/managers/expert_location.py`
   - 修复了除零错误
   - 改进了expert分配逻辑

2. `sglang-0.4.7/python/sglang/srt/distributed/parallel_state.py`
   - 添加了`get_moe_expert_parallel_world_size`函数
   - 添加了`get_moe_expert_parallel_rank`函数

3. `sglang-0.4.7/python/sglang/srt/models/qwen3_moe.py`
   - 为`Qwen3MoeModel`添加了完整的tensor parallel支持
   - 为`Qwen3MoeForCausalLM`添加了tensor parallel支持
   - 添加了`supports_tp_plan`和`_tp_plan`配置
   - 实现了`tensor_parallel`方法

4. `sglang-0.4.7/python/sglang/srt/models/transformers.py`
   - 改进了`tensor_parallel`方法的错误检查
   - 添加了对模型属性的安全检查

### 测试脚本修改
1. `test_single_expert_ep.py`
   - 添加了`SINGLE_EXPERT_MODE=dp`环境变量
   - 使用正确的EP配置

2. `test_single_expert_tp.py`
   - 添加了`SINGLE_EXPERT_MODE=tp`环境变量
   - 使用正确的TP配置

3. `test_hybrid_parallel.py`
   - 添加了环境变量配置
   - 改进了配置管理

4. `test_tp_support.py` (新增)
   - 专门测试tensor parallel支持
   - 验证TP=8配置是否正常工作

5. `test_single_expert_tp_fixed.py` (新增)
   - 专门测试单expert模型的tensor parallel支持
   - 验证修复后的代码是否能正确处理单expert模型的TP=8配置

## 测试验证

### 1. 单expert模型Tensor Parallel测试 (推荐)
```bash
# 测试单expert模型的Tensor Parallel支持
python3 test_single_expert_tp_fixed.py
```

### 2. Tensor Parallel支持测试
```bash
# 测试Tensor Parallel支持
python3 test_tp_support.py
```

### 3. 简化测试
```bash
# 使用简化的配置进行测试
python3 test_simple_ep.py
```

### 4. 基础测试
```bash
# 测试Expert Parallel
python3 test_single_expert_ep.py

# 测试Tensor Parallel
python3 test_single_expert_tp.py
```

### 5. 混合测试
```bash
# 运行两种配置的对比测试
python3 test_hybrid_parallel.py --config both
```

### 6. 使用启动脚本
```bash
# Linux/Mac
./run_tests.sh --ep
./run_tests.sh --tp
./run_tests.sh --all
```

## 注意事项

1. **模型路径**: 确保模型路径正确，并且模型已经通过`prune_qwen3_a22B-to_single_expert.py`处理
2. **GPU数量**: 确保有足够的GPU资源（推荐8张GPU）
3. **内存配置**: 根据实际情况调整`max_total_tokens`和`chunked_prefill_size`参数
4. **环境变量**: 确保正确设置了`SINGLE_EXPERT_MODE`环境变量
5. **简化配置**: 建议先使用简化配置测试基本功能，再逐步增加复杂度
6. **Tensor Parallel**: 现在Qwen3MoeModel完全支持tensor parallel，可以使用TP=8配置

## 性能对比

修复后的配置应该能够正常运行，并提供以下性能对比：

| 配置 | Expert层策略 | 其他层策略 | 优势 | 复杂度 | 支持状态 |
|------|-------------|-----------|------|--------|----------|
| 简化配置 | DP模式 | TP=1, DP=1 | 稳定可靠，易于调试 | 低 | ✅ |
| Expert Parallel | DP=8 (每GPU完整副本) | TP=4, DP=2 | 减少通信开销，提高吞吐量 | 中 | ✅ |
| Tensor Parallel | TP=8 (GPU切分) | TP=8 | 减少内存占用，支持更大模型 | 高 | ✅ |

## 故障排除

如果仍然遇到问题，请检查：

1. **日志信息**: 查看详细的错误日志
2. **环境变量**: 确认`SINGLE_EXPERT_MODE`设置正确
3. **模型配置**: 确认模型配置文件中的expert数量
4. **GPU资源**: 确认GPU数量和内存充足
5. **简化测试**: 先运行`test_simple_ep.py`确保基本功能正常
6. **Tensor Parallel测试**: 运行`test_tp_support.py`验证TP支持

## 后续优化

1. **动态配置**: 支持运行时动态切换并行策略
2. **性能调优**: 根据实际硬件优化参数配置
3. **监控指标**: 添加更详细的性能监控
4. **自动化测试**: 完善自动化测试流程
5. **错误处理**: 改进错误处理和恢复机制
6. **混合并行**: 支持更复杂的混合并行策略
